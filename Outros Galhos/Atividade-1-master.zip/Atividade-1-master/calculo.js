var valorum = 12;
var valordois = 15;
var valortres = 12
total = valorum + valordois / valortres;
console.log(valorum + valordois / valortres);
console.log ((valorum + valordois) / valortres);

console.log ("------------------------------------");
var valorx = 12;
var valory = 15;
var valorz = 12

//Elemento chamado Overwrite ou sobreescrita - escrever por cima de um valor já declarado
total = valorx + valory;
total = total/valorz;
console.log(total);