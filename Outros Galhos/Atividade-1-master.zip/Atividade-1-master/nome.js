console.log('Alan')
var nome = 'Alan';
var sobrenome = 'Teles';
var idade = 22;
var nomecompleto;

nomecompleto = nome + sobrenome + idade;
console.log(nomecompleto);