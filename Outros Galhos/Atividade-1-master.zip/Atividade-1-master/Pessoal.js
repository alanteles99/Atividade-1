console.log('Alan')
var nome = 'Alan';
var email = "alan.teles1999@hotmail.com";
var endereço = 'travessa ayrton senna';

console.log("meu nome é " + nome + " " + email + " " + endereço);