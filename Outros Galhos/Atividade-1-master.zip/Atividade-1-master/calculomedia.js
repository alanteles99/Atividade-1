var mediaum = 6;
var mediadois = 4;
var mediatres = 10;
var mediaquatro = 3;
var divisao = 4;
total = mediaum + mediadois + mediatres + mediaquatro;
tetal = total/divisao;
if (total >= 7){
    console.log("aprovado");
} else{
    console.log("reprovado");
}
